# This will be a default script that can install packages on Windows hosts.
# Documentation: https://fleetdm.com/docs/configuration/yaml-files#packages
