cp /var/log/orbit/orbit.stderr.log ~/Library/Logs/Fleet/fleet-desktop.log /Users/Shared

echo "Successfully copied fleetd logs to the /Users/Shared folder."

echo "To retrieve logs, ask the end user to open Finder and in the menu bar select Go > Go to Folder."

echo "Then, ask the end user to type in /Users/Shared, press Return, and locate orbit.stderr.log (Orbit logs) and fleet-desktop.log (Fleet Desktop logs) files."