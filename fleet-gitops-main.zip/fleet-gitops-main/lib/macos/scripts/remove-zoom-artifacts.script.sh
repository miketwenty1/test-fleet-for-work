# This will be a script that removes Zoom artifacts from macOS hosts.
