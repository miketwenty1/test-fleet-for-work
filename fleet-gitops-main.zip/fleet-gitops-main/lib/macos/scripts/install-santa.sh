# This will be a script that installs Santa onto macOS hosts.
# Documentation: https://fleetdm.com/docs/configuration/yaml-files#packages